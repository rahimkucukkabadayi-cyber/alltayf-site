import type { AppProps } from 'next/app'
import Head from 'next/head'
import '../styles/globals.css'

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <title>Alltayf Evreni — alltayf.com</title>
        <meta name="description" content="Işığın tüm tayflarını birleştiren yaşam, teknoloji ve bilgelik ekosistemi." />
        <meta property="og:title" content="Alltayf Evreni" />
        <meta property="og:description" content="Işığın tüm tayflarını birleştiren yaşam, teknoloji ve bilgelik ekosistemi." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://alltayf.com" />
        <meta property="og:image" content="/og.jpg" />
        <link rel="canonical" href="https://alltayf.com" />
      </Head>
      <Component {...pageProps} />
    </>
  )
}
