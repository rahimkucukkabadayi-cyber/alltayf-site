import { useState } from 'react'
import { Sparkles, Leaf, Globe2, Github, Rocket, Mail, Send } from 'lucide-react'

type Lang = 'tr' | 'en'

const dict = {
  tr: {
    brand: 'Alltayf Evreni',
    subtitle: 'Işığın tüm tayflarını birleştiren yaşam, teknoloji ve bilgelik ekosistemi',
    ctaPrimary: 'Hemen Başla',
    ctaSecondary: 'Whitepaper',
    aboutTitle: 'Neden Alltayf?',
    aboutBody: 'Alltayf, doğa, hukuk, teknoloji ve topluluk temelleriyle kurulan, bilincin farklı tayflarını birleştiren bir evrendir.',
    tokenTitle: 'KEB Token — Temeller',
    tokenSupply: 'Toplam Arz',
    tokenBurn: 'Yakım Mekanizması',
    tokenGovernance: 'Yönetim İmzaları',
    roadmapTitle: 'Yol Haritası',
    roadmapNow: 'Şimdi: Alltayf.com yayına hazırlanıyor',
    roadmapNext: 'Sonraki: Topluluk ve ekosistem lansmanı',
    contactTitle: 'İletişim / Bülten',
    emailPlaceholder: 'E-posta adresiniz',
    subscribe: 'Kaydol',
    footerNote: `© ${new Date().getFullYear()} Alltayf.com — Tüm hakları saklıdır.`,
    liveDemo: 'Canlı Demo',
  },
  en: {
    brand: 'Alltayf Universe',
    subtitle: 'An ecosystem uniting all spectrums of light through life, technology, and wisdom.',
    ctaPrimary: 'Get Started',
    ctaSecondary: 'Whitepaper',
    aboutTitle: 'Why Alltayf?',
    aboutBody: 'Alltayf is a universe uniting different spectrums of consciousness — built on nature, law, technology, and community.',
    tokenTitle: 'KEB Token — Fundamentals',
    tokenSupply: 'Total Supply',
    tokenBurn: 'Burn Mechanism',
    tokenGovernance: 'Multisig Governance',
    roadmapTitle: 'Roadmap',
    roadmapNow: 'Now: Alltayf.com preparation',
    roadmapNext: 'Next: Community & ecosystem launch',
    contactTitle: 'Contact / Newsletter',
    emailPlaceholder: 'Your email address',
    subscribe: 'Subscribe',
    footerNote: `© ${new Date().getFullYear()} Alltayf.com — All rights reserved.`,
    liveDemo: 'Live Demo',
  },
}

export default function Home() {
  const [lang, setLang] = useState<Lang>('tr')
  const t = (k: keyof typeof dict['tr']) => (dict[lang] as any)[k]

  const Stat = ({ label, value }: { label: string; value: string }) => (
    <div className="flex flex-col items-start gap-1">
      <span className="text-xs uppercase tracking-widest opacity-70">{label}</span>
      <span className="text-2xl font-semibold">{value}</span>
    </div>
  )

  return (
    <div className="min-h-screen">
      {/* Top bar */}
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-2xl grid place-items-center shadow-sm border">
              <Sparkles className="h-5 w-5" />
            </div>
            <strong className="text-lg">{t('brand')}</strong>
          </div>
          <div className="flex items-center gap-2">
            <span className="badge">{lang.toUpperCase()}</span>
            <button className="btn btn-outline" onClick={() => setLang(lang === 'tr' ? 'en' : 'tr')}>TR / EN</button>
            <a href="https://alltayf.com" className="hidden md:block"><button className="btn btn-primary"><Rocket className="h-4 w-4" />{t('liveDemo')}</button></a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="container pt-16 pb-10">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
              {t('brand')} <span className="block text-2xl md:text-3xl font-medium opacity-70">{t('subtitle')}</span>
            </h1>
            <div className="flex flex-wrap gap-3">
              <button className="btn btn-primary"><Leaf className="h-5 w-5" />{t('ctaPrimary')}</button>
              <a href="/whitepaper.pdf" target="_blank" rel="noreferrer"><button className="btn btn-outline"><Globe2 className="h-5 w-5" />{t('ctaSecondary')}</button></a>
              <a href="https://github.com/alltayf" target="_blank" rel="noreferrer"><button className="btn"><Github className="h-5 w-5" />GitHub</button></a>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <Stat label={t('tokenSupply')} value="100,000,000" />
              <Stat label={t('tokenBurn')} value="%1–%5 dinamik" />
              <Stat label={t('tokenGovernance')} value="3/5 multisig" />
            </div>
          </div>
          <div>
            <div className="card">
              <div className="card-body">
                <h3 className="text-lg font-semibold flex items-center gap-2"><Sparkles className="h-5 w-5" />{t('aboutTitle')}</h3>
                <p className="text-slate-700 mt-2">{t('aboutBody')}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="badge">Law-Tech</span>
                  <span className="badge">Eco</span>
                  <span className="badge">Token</span>
                  <span className="badge">Community</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics */}
      <section className="container py-6">
        <div className="card">
          <div className="card-body">
            <h3 className="text-lg font-semibold">{t('tokenTitle')}</h3>
            <div className="grid md:grid-cols-3 gap-6 mt-4">
              <div className="space-y-2">
                <h4 className="font-semibold">{t('tokenSupply')}</h4>
                <p className="text-sm opacity-80">100M sabit arz, kurucu cüzdan kilitli, topluluk havuzu ve likidite planı ile dağıtım.</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">{t('tokenBurn')}</h4>
                <p className="text-sm opacity-80">Gelir odaklı yakım tetikleyicileri; işlem bazlı min. %1, proje fazlarına göre esnek.</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">{t('tokenGovernance')}</h4>
                <p className="text-sm opacity-80">Çoklu imza (3/5) ile güvenli fon hareketleri; şeffaf cüzdan raporları.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="container py-6">
        <div className="card">
          <div className="card-body">
            <h3 className="text-lg font-semibold">{t('roadmapTitle')}</h3>
            <ol className="grid md:grid-cols-2 gap-4 list-decimal pl-6 mt-3">
              <li className="pr-4">{t('roadmapNow')}</li>
              <li className="pr-4">{t('roadmapNext')}</li>
              <li className="pr-4">Audit, şeffaflık panosu, KEP/uyum sayfaları</li>
              <li className="pr-4">Enerji, ekoloji ve hukuk temelli alt projeler</li>
            </ol>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="container py-10">
        <div className="card">
          <div className="card-body">
            <h3 className="text-lg font-semibold flex items-center gap-2"><Mail className="h-5 w-5" />{t('contactTitle')}</h3>
            <div className="grid md:grid-cols-2 gap-3 mt-3">
              <input placeholder={t('emailPlaceholder') ?? ''} className="rounded-xl border px-4 py-3" />
              <button className="btn btn-primary"><Send className="h-4 w-4" />{t('subscribe')}</button>
            </div>
            <p className="text-xs opacity-70 mt-3">KVKK notu: E-posta yalnızca bülten ve proje duyuruları için kullanılacaktır.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t mt-8">
        <div className="container py-10 text-sm opacity-80">{t('footerNote')} — <a className="underline" href="https://alltayf.com">alltayf.com</a></div>
      </footer>
    </div>
  )
}
